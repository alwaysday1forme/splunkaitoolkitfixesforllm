#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="${APP_ROOT:-/opt/splunk/etc/apps/Splunk_ML_Toolkit}"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_ROOT="$PKG_DIR/deploy/Splunk_ML_Toolkit"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_ROOT="$APP_ROOT/optimization_backup_$STAMP"

FILES=(
  "bin/ai_commander/llm_base.py"
  "bin/ai_commander/llm_factory.py"
  "bin/processors/AiCommanderProcessor.py"
  "bin/connection_config_manager/llm/llm_config_manager.py"
  "bin/connection_config_manager/utils/common_utils.py"
  "bin/chunked_controller.py"
)

echo "Target app root: $APP_ROOT"
echo "Backup directory: $BACKUP_ROOT"

for rel in "${FILES[@]}"; do
  [[ -f "$APP_ROOT/$rel" ]] || { echo "ERROR: missing target $APP_ROOT/$rel" >&2; exit 1; }
  [[ -f "$SRC_ROOT/$rel" ]] || { echo "ERROR: missing package file $SRC_ROOT/$rel" >&2; exit 1; }
done

mkdir -p "$BACKUP_ROOT"

for rel in "${FILES[@]}"; do
  target="$APP_ROOT/$rel"
  src="$SRC_ROOT/$rel"
  backup="$BACKUP_ROOT/$rel"

  mkdir -p "$(dirname "$backup")"
  cp -a "$target" "$backup"

  owner="$(stat -c '%u' "$target")"
  group="$(stat -c '%g' "$target")"
  mode="$(stat -c '%a' "$target")"

  cp "$src" "$target"
  chown "$owner:$group" "$target"
  chmod "$mode" "$target"
  echo "Installed: $rel"
done

PYTHON="/opt/splunk/etc/apps/Splunk_SA_Scientific_Python_linux_x86_64/bin/linux_x86_64/4_3_1/bin/python"
if [[ -x "$PYTHON" ]]; then
  echo "Running Python compile validation..."
  "$PYTHON" -m py_compile "${FILES[@]/#/$APP_ROOT/}"
  echo "Compile validation passed."
else
  echo "WARNING: expected Scientific Python interpreter not found; py_compile skipped."
fi

echo
echo "Installation complete."
echo "Rollback source: $BACKUP_ROOT"
